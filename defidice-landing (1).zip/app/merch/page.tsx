import type { Metadata } from "next"
import Header from "@/components/header"
import MerchSection from "@/components/merch-section"
import Footer from "@/components/footer"

export const metadata: Metadata = {
  title: "Dicerix Merchandise",
  description: "Exclusive Dicerix merchandise featuring Lady Fortuna and our digital agents.",
}

export default function MerchPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-900 to-black text-white">
      <Header />
      <main className="pt-20">
        <section className="py-20">
          <div className="container mx-auto px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
              Dicerix Merchandise
            </h1>
            <p className="text-xl text-zinc-400 mb-12">
              Gear up with exclusive Dicerix merch and show your support for the digital revolution.
            </p>
            <MerchSection />
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

