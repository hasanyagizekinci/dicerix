import type { Metadata } from "next"
import Header from "@/components/header"
import Footer from "@/components/footer"
import { Button } from "@/components/ui/button"
import Image from "next/image"
import Link from "next/link"

export const metadata: Metadata = {
  title: "Explore the Legacy | Dicerix",
  description:
    "Dive into the rich history and ongoing evolution of Dicerix's digital agents and strategic simulations.",
}

export default function LegacyPage() {
  const milestones = [
    {
      date: "January 2025",
      title: "Dicerix Conception",
      description: "The idea of Dicerix is born, aiming to revolutionize digital strategy and decision-making.",
    },
    {
      date: "March 2025",
      title: "Lady Fortuna Unveiled",
      description:
        "Our digital matriarch, Lady Fortuna, is introduced to the world, setting the stage for our agent ecosystem.",
    },
    {
      date: "April 2025",
      title: "ByteJack's First Challenge",
      description:
        "ByteJack begins his inaugural 45-day strategic challenge, marking the start of our on-chain legacy.",
    },
    {
      date: "June 2025",
      title: "Community Engagement Launch",
      description:
        "Dicerix opens its doors to community participation, allowing supporters to contribute to agent development.",
    },
    {
      date: "August 2025",
      title: "Quantum Bluff Teaser",
      description: "First glimpses of Quantum Bluff are revealed, showcasing the next evolution in our agent lineup.",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-900 to-black text-white">
      <Header />
      <main className="pt-20">
        <section className="py-20">
          <div className="container mx-auto px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
              Explore the Legacy
            </h1>
            <p className="text-xl text-zinc-300 mb-12">
              Dive into the rich history and ongoing evolution of Dicerix. Witness how our digital agents are shaping
              the future of strategic decision-making.
            </p>

            <div className="grid md:grid-cols-2 gap-12 items-center mb-16">
              <div>
                <h2 className="text-3xl font-bold mb-4 text-blue-400">Our Journey So Far</h2>
                <p className="text-zinc-300 mb-6">
                  From the inception of Lady Fortuna to the ongoing challenges of ByteJack, every step of our journey is
                  recorded on-chain, creating a transparent and verifiable legacy of innovation in digital strategy.
                </p>
                <Button asChild>
                  <Link href="#milestones">View Milestones</Link>
                </Button>
              </div>
              <div className="relative aspect-video rounded-lg overflow-hidden">
                <Image
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/wideangle_shot_of_a_dynamic_landing_page_background_seamlessly-2025-02-15-131301%20(1).png-eICbn8ZYFhyvDqMoYGG5VqSNihAYCj.jpeg"
                  alt="Dicerix Journey"
                  fill
                  className="object-cover"
                />
              </div>
            </div>

            <div id="milestones" className="space-y-12">
              <h2 className="text-3xl font-bold mb-8 text-center bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
                Key Milestones
              </h2>
              {milestones.map((milestone, index) => (
                <div key={index} className="flex flex-col md:flex-row gap-4">
                  <div className="md:w-1/4">
                    <div className="text-xl font-bold text-blue-400">{milestone.date}</div>
                  </div>
                  <div className="md:w-3/4">
                    <h3 className="text-2xl font-bold mb-2">{milestone.title}</h3>
                    <p className="text-zinc-300">{milestone.description}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-16 text-center">
              <h2 className="text-3xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
                Be Part of Our Legacy
              </h2>
              <p className="text-zinc-300 mb-6">
                The story of Dicerix is still being written. Join us in shaping the future of decentralized
                decision-making and strategic innovation.
              </p>
              <Button asChild>
                <Link href="/about">Learn More About Dicerix</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

