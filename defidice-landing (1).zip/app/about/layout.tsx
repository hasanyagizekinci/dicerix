import type React from "react"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "About DeFiDice",
  description:
    "Learn about DeFiDice's philosophy, story, and mission in revolutionizing digital strategy and decision-making.",
}

export default function AboutLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return <>{children}</>
}

