import Header from "@/components/header"
import AboutPageClient from "@/components/about-page-client"
import Footer from "@/components/footer"

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-900 to-black text-white">
      <Header />
      <main className="pt-20">
        <AboutPageClient />
      </main>
      <Footer />
    </div>
  )
}

