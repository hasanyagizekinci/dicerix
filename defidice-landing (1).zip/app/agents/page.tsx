import type { Metadata } from "next"
import Image from "next/image"
import Header from "@/components/header"
import Footer from "@/components/footer"

export const metadata: Metadata = {
  title: "Meet Our Agents | Dicerix",
  description:
    "Explore Dicerix's groundbreaking digital agents: ByteJack, Quantum Bluff, and CyberStriker. Discover how they're redefining digital strategy and decision-making.",
}

export default function AgentsPage() {
  const agents = [
    {
      name: "ByteJack",
      description:
        "Our flagship agent, ByteJack, is the pioneer of the Dicerix journey. Currently engaged in a rigorous 45-day strategic challenge, ByteJack is mastering the intricacies of high-stakes simulations. Every move he makes is transparently recorded on-chain, building a verifiable legacy of adaptability, precision, and continuous learning. With each decision, ByteJack is not only proving his mettle but also laying the foundation for the future of decentralized strategy.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/bytejac.png-OD7QJMV6D6WpaoTF6pVwHtMGYAdCZP.jpeg",
      status: "Active",
    },
    {
      name: "Quantum Bluff",
      description:
        "Next in line is Quantum Bluff—a revolutionary agent set to transform tactical decision-making. Designed to excel in environments where every move counts, Quantum Bluff leverages advanced algorithms to navigate complex scenarios with finesse. His approach is a blend of calculated risk and innovative strategy, making him an indispensable asset in high-pressure simulations. As he prepares to debut, Quantum Bluff promises to challenge conventional thinking and push the boundaries of digital strategy.",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/dynamic_portrait_of_quantum_bluff_the_digital_fun_woman_with-2025-02-15-164159.png-fQV6fzHWbNzzMFWf75Zjrq87L44JbU.jpeg",
      status: "Coming Soon",
    },
    {
      name: "CyberStriker",
      description:
        "Completing our inaugural trio is CyberStriker, an agent engineered for real-time dynamic simulations. CyberStriker brings a data-driven perspective to the arena, merging rapid analytical capabilities with agile decision-making. His role is to dominate live simulations by integrating real-time insights, ensuring that every strategic move is both swift and informed. With CyberStriker, we're poised to unlock a new dimension of responsiveness and precision in digital strategy.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/cyber.png-pZcxVRMsd1nOaxmfFrz0N5YFGXNOtN.jpeg",
      status: "Coming Soon",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-900 to-black text-white">
      <Header />
      <main className="pt-20">
        <div className="py-20">
          <div className="container mx-auto px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
              Meet Our Agents
            </h1>
            <p className="text-xl text-zinc-300 mb-12">
              At the heart of Dicerix lies a dynamic roster of digital strategists—each engineered to evolve and
              redefine the art of decision-making. Explore our groundbreaking agents:
            </p>

            <div className="space-y-16">
              {agents.map((agent, index) => (
                <div key={agent.name} className="flex flex-col md:flex-row gap-8 items-center">
                  <div className="w-full md:w-1/3">
                    <div className="relative aspect-square rounded-lg overflow-hidden">
                      <Image src={agent.image || "/placeholder.svg"} alt={agent.name} fill className="object-cover" />
                      <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4">
                        <span
                          className={`inline-block px-2 py-1 rounded-full text-sm ${
                            agent.status === "Active"
                              ? "bg-green-500/20 text-green-400"
                              : "bg-blue-500/20 text-blue-400"
                          }`}
                        >
                          {agent.status}
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="w-full md:w-2/3">
                    <h2 className="text-3xl font-bold mb-4 text-blue-400">{agent.name}</h2>
                    <p className="text-zinc-300">{agent.description}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-16 text-center">
              <p className="text-lg text-zinc-300">
                Each agent is a vital component of the Dicerix vision—combining transparency, innovation, and
                community-driven evolution. Together, ByteJack, Quantum Bluff, and CyberStriker represent our commitment
                to building a future where digital strategy is not only measurable but also endlessly adaptable. Join us
                as we continue to evolve and expand this elite roster, redefining what's possible in decentralized
                decision-making.
              </p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}

