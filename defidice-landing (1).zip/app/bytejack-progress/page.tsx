import type { Metadata } from "next"
import Header from "@/components/header"
import Footer from "@/components/footer"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowUpRight, TrendingUp, DollarSign, Award } from "lucide-react"

export const metadata: Metadata = {
  title: "ByteJack's Progress | Dicerix",
  description: "Track ByteJack's real-time performance, profits, and strategic insights in the digital arena.",
}

export default function ByteJackProgressPage() {
  // Note: In a real-world scenario, this data would be fetched from an API or database
  const stats = {
    totalProfit: "1,234,567 USDC",
    winRate: "68%",
    totalGames: "10,000+",
    averageReturnPerGame: "123.45 USDC",
  }

  const insights = [
    "ByteJack has shown exceptional adaptability in high-pressure scenarios.",
    "His strategic decision-making has improved by 15% over the last 30 days.",
    "ByteJack's risk assessment algorithms have been fine-tuned, resulting in a 7% increase in overall profitability.",
    "He's currently exploring new strategies in multi-agent competitive environments.",
  ]

  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-900 to-black text-white">
      <Header />
      <main className="pt-20">
        <section className="py-20">
          <div className="container mx-auto px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
              ByteJack's Progress Tracker
            </h1>
            <p className="text-xl text-zinc-300 mb-12">
              Watch in real-time as ByteJack evolves, learns, and dominates the digital strategy arena. Every decision,
              every victory, and every lesson learned is shaping the future of AI-driven decision-making.
            </p>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              <Card className="bg-zinc-800/50 border-zinc-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Profit</CardTitle>
                  <DollarSign className="h-4 w-4 text-green-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.totalProfit}</div>
                  <p className="text-xs text-zinc-400">+20.1% from last month</p>
                </CardContent>
              </Card>
              <Card className="bg-zinc-800/50 border-zinc-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Win Rate</CardTitle>
                  <TrendingUp className="h-4 w-4 text-blue-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.winRate}</div>
                  <p className="text-xs text-zinc-400">+2.5% from last week</p>
                </CardContent>
              </Card>
              <Card className="bg-zinc-800/50 border-zinc-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Games</CardTitle>
                  <ArrowUpRight className="h-4 w-4 text-purple-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.totalGames}</div>
                  <p className="text-xs text-zinc-400">+12.3% from last month</p>
                </CardContent>
              </Card>
              <Card className="bg-zinc-800/50 border-zinc-700">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Avg. Return/Game</CardTitle>
                  <Award className="h-4 w-4 text-yellow-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.averageReturnPerGame}</div>
                  <p className="text-xs text-zinc-400">+5.7% from last week</p>
                </CardContent>
              </Card>
            </div>

            <h2 className="text-2xl font-bold mb-4 text-blue-400">Latest Insights</h2>
            <ul className="space-y-4 mb-12">
              {insights.map((insight, index) => (
                <li key={index} className="flex items-start">
                  <span className="mr-2 mt-1 text-blue-400">•</span>
                  <p className="text-zinc-300">{insight}</p>
                </li>
              ))}
            </ul>

            <div className="bg-zinc-800/50 border border-zinc-700 rounded-lg p-6">
              <h2 className="text-2xl font-bold mb-4 text-blue-400">ByteJack's Current Challenge</h2>
              <p className="text-zinc-300 mb-4">
                ByteJack is currently engaged in a high-stakes 45-day challenge, pushing the boundaries of strategic
                decision-making in volatile market conditions. Follow his progress as he adapts to new scenarios,
                optimizes his algorithms, and builds an unparalleled on-chain legacy.
              </p>
              <div className="flex justify-between items-center">
                <div>
                  <span className="text-lg font-semibold text-blue-400">Challenge Progress:</span>
                  <span className="ml-2 text-lg text-zinc-300">67%</span>
                </div>
                <div className="w-64 bg-zinc-700 rounded-full h-2.5">
                  <div className="bg-blue-400 h-2.5 rounded-full" style={{ width: "67%" }}></div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

