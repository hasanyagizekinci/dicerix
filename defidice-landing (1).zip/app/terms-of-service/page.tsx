import type { Metadata } from "next"
import Header from "@/components/header"
import Footer from "@/components/footer"

export const metadata: Metadata = {
  title: "Terms of Service | Dicerix",
  description: "Dicerix's Terms of Service outlining the rules and regulations for using our site.",
}

export default function TermsOfServicePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-900 to-black text-white">
      <Header />
      <main className="pt-20">
        <div className="py-20">
          <div className="container mx-auto px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
              Terms of Service
            </h1>
            <div className="prose prose-invert max-w-none">
              <p>Last updated: {new Date().toLocaleDateString()}</p>

              <p className="mb-6">
                Welcome to Dicerix. By accessing and using our website (the "Site"), you agree to be bound by these
                Terms of Service ("Terms"). If you do not agree with these Terms, please do not use the Site.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4 text-blue-400">1. Use of the Site</h2>
              <h3 className="text-xl font-semibold mt-4 mb-2 text-purple-400">Purpose:</h3>
              <p>
                The Site is provided for informational and community engagement purposes related to our digital strategy
                simulation platform. Dicerix is not a platform for financial transactions or investment advice.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4 text-blue-400">2. Account Registration and Security</h2>
              <h3 className="text-xl font-semibold mt-4 mb-2 text-purple-400">Optional Registration:</h3>
              <p>
                Certain features of the Site may require you to register for an account. When you create an account, you
                agree to provide accurate, current, and complete information.
              </p>
              <h3 className="text-xl font-semibold mt-4 mb-2 text-purple-400">Account Responsibility:</h3>
              <p>
                You are responsible for maintaining the confidentiality of your account information and password, and
                for all activities that occur under your account. Please notify us immediately if you suspect any
                unauthorized use.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4 text-blue-400">3. Intellectual Property</h2>
              <h3 className="text-xl font-semibold mt-4 mb-2 text-purple-400">Ownership:</h3>
              <p>
                All content on the Site—including text, graphics, logos, images, and software—is the property of Dicerix
                or its licensors and is protected by applicable copyright and intellectual property laws.
              </p>
              <h3 className="text-xl font-semibold mt-4 mb-2 text-purple-400">Limited License:</h3>
              <p>
                We grant you a limited, non-exclusive, non-transferable license to access and use the Site for personal,
                non-commercial purposes only. You may not reproduce, distribute, or create derivative works from any
                content on the Site without our prior written consent.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4 text-blue-400">4. User Conduct</h2>
              <h3 className="text-xl font-semibold mt-4 mb-2 text-purple-400">Prohibited Activities:</h3>
              <p>
                You agree not to use the Site for any unlawful purpose or in a manner that could damage, disable, or
                impair the Site. This includes, but is not limited to:
              </p>
              <ul className="list-disc pl-6 mb-6 text-zinc-300">
                <li>Unauthorized commercial use.</li>
                <li>Posting or transmitting any harmful, offensive, or otherwise objectionable content.</li>
                <li>Attempting to bypass or interfere with security measures on the Site.</li>
              </ul>
              <h3 className="text-xl font-semibold mt-4 mb-2 text-purple-400">Community Engagement:</h3>
              <p>
                We encourage constructive discussion and community interaction. However, we reserve the right to remove
                any content that violates these Terms or is deemed inappropriate at our sole discretion.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4 text-blue-400">5. Disclaimers</h2>
              <h3 className="text-xl font-semibold mt-4 mb-2 text-purple-400">No Warranty:</h3>
              <p>
                The Site and all information provided on it are offered on an "as is" basis without warranties of any
                kind, either express or implied. We do not guarantee the accuracy, completeness, or reliability of any
                content on the Site.
              </p>
              <h3 className="text-xl font-semibold mt-4 mb-2 text-purple-400">Limitation of Liability:</h3>
              <p>
                In no event shall Dicerix, its affiliates, or their respective officers, directors, or employees be
                liable for any indirect, incidental, special, or consequential damages arising out of or in connection
                with your use of the Site. Your use of the Site is at your sole risk.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4 text-blue-400">6. Modifications</h2>
              <h3 className="text-xl font-semibold mt-4 mb-2 text-purple-400">Changes to Terms:</h3>
              <p>
                We reserve the right to modify these Terms at any time. Any changes will be effective immediately upon
                posting on the Site. Your continued use of the Site after such modifications constitutes your acceptance
                of the new Terms.
              </p>
              <h3 className="text-xl font-semibold mt-4 mb-2 text-purple-400">Site Updates:</h3>
              <p>We may update, suspend, or discontinue any part of the Site at any time without notice.</p>

              <h2 className="text-2xl font-bold mt-8 mb-4 text-blue-400">7. Governing Law</h2>
              <p>
                These Terms shall be governed by and construed in accordance with the laws of the jurisdiction where
                Dicerix is registered, without regard to its conflict of laws provisions.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4 text-blue-400">8. Contact Information</h2>
              <p>If you have any questions or concerns about these Terms or our Site, please contact us at:</p>
              <p>Email: legal@dicerix.com</p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}

