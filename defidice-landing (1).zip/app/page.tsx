import Header from "@/components/header"
import HeroSection from "@/components/hero-section"
import LadyFortunaSection from "@/components/lady-fortuna-section"
import ByteJackSection from "@/components/bytejack-section"
import GladiatorsSection from "@/components/gladiators-section"
import OperationsSection from "@/components/operations-section"
import MerchSection from "@/components/merch-section"
import FAQSection from "@/components/faq-section"
import RoadmapSummary from "@/components/roadmap-summary"
import CtaSection from "@/components/cta-section"
import Footer from "@/components/footer"

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Header />
      <main className="pt-20">
        <HeroSection />
        <LadyFortunaSection />
        <ByteJackSection />
        <GladiatorsSection />
        <OperationsSection />
        <RoadmapSummary />
        <MerchSection />
        <FAQSection />
        <CtaSection />
      </main>
      <Footer />
    </div>
  )
}

