import type { Metadata } from "next"
import Header from "@/components/header"
import Footer from "@/components/footer"

export const metadata: Metadata = {
  title: "Privacy Policy | Dicerix",
  description: "Dicerix's privacy policy outlining how we collect, use, and protect your personal information.",
}

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-900 to-black text-white">
      <Header />
      <main className="pt-20">
        <div className="py-20">
          <div className="container mx-auto px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
              Privacy Policy
            </h1>
            <div className="prose prose-invert max-w-none">
              <p>Last updated: {new Date().toLocaleDateString()}</p>

              <h2 className="text-2xl font-bold mt-8 mb-4 text-blue-400">1. Introduction</h2>
              <p>
                Welcome to Dicerix. We are committed to protecting your privacy while you explore our digital strategy
                simulation platform. This Privacy Policy explains what information we collect on our landing page, how
                we use it, and the steps we take to safeguard it. By using our site, you agree to the terms of this
                policy.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4 text-blue-400">2. Information We Collect</h2>
              <h3 className="text-xl font-semibold mt-4 mb-2 text-purple-400">Personal Information:</h3>
              <p>
                We may collect basic information (such as your email address or social media handle) if you voluntarily
                subscribe to updates or contact us. This information is used solely for communication purposes.
              </p>
              <h3 className="text-xl font-semibold mt-4 mb-2 text-purple-400">Usage Data:</h3>
              <p>
                Our site automatically collects non-personal data such as IP addresses, browser type, device
                information, and pages visited. This helps us understand how visitors interact with our site and improve
                the user experience.
              </p>
              <h3 className="text-xl font-semibold mt-4 mb-2 text-purple-400">Cookies:</h3>
              <p>
                We use cookies and similar technologies to enhance your experience, track site usage, and manage session
                data. You can adjust your browser settings to manage or disable cookies, though some features of our
                site may not function properly without them.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4 text-blue-400">3. How We Use Your Information</h2>
              <ul className="list-disc pl-6 mb-6 text-zinc-300">
                <li>To provide and maintain our landing page.</li>
                <li>To improve the design, content, and functionality of our site.</li>
                <li>To communicate with you about updates, news, or promotional material related to Dicerix.</li>
                <li>To analyze site usage and trends, ensuring a better experience for our visitors.</li>
                <li>To protect the security and integrity of our site.</li>
              </ul>

              <h2 className="text-2xl font-bold mt-8 mb-4 text-blue-400">4. Sharing Your Information</h2>
              <p>
                We do not sell or rent your personal data. We may share information with third-party service providers
                (such as analytics or hosting providers) only as necessary to operate our site. These providers are
                contractually obligated to protect your data and use it solely for the purposes we specify. We will also
                disclose information if required by law or to protect our rights and safety.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4 text-blue-400">5. Data Security</h2>
              <p>
                We take reasonable steps to protect your data from unauthorized access, use, or disclosure. While we
                strive to safeguard your information, no online transmission is completely secure. By using our site,
                you acknowledge that we cannot guarantee absolute security.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4 text-blue-400">6. Your Rights</h2>
              <p>
                Depending on your location, you may have rights regarding your personal data, such as the right to
                access, update, or request deletion of your information. If you wish to exercise these rights, please
                contact us using the details provided below.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4 text-blue-400">7. Third-Party Links</h2>
              <p>
                Our landing page may include links to third-party websites for additional information. Please note that
                we are not responsible for the privacy practices or content of these external sites. We encourage you to
                review the privacy policies of any third-party sites you visit.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4 text-blue-400">8. Changes to This Privacy Policy</h2>
              <p>
                We may update this Privacy Policy from time to time. Any changes will be posted on this page with an
                updated effective date. We recommend reviewing this policy periodically to stay informed about how your
                information is protected.
              </p>

              <h2 className="text-2xl font-bold mt-8 mb-4 text-blue-400">9. Contact Us</h2>
              <p>
                If you have any questions or concerns about this Privacy Policy or our practices, please contact us at:
              </p>
              <p>Email: privacy@dicerix.com</p>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}

