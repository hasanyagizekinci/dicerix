import type { Metadata } from "next"
import Header from "@/components/header"
import Footer from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Twitter, MessageCircle, Send } from "lucide-react"
import Link from "next/link"

export const metadata: Metadata = {
  title: "Join the Revolution | Dicerix",
  description: "Become part of the Dicerix community and help shape the future of decentralized decision-making.",
}

export default function JoinPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-900 to-black text-white">
      <Header />
      <main className="pt-20">
        <section className="py-20">
          <div className="container mx-auto px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
              Join the Dicerix Revolution
            </h1>
            <p className="text-xl text-zinc-300 mb-12">
              Be part of the movement that's reshaping digital strategy and decentralized decision-making. Your
              involvement can help drive the evolution of our agents and the future of Dicerix.
            </p>

            <div className="grid md:grid-cols-2 gap-12 mb-16">
              <div>
                <h2 className="text-2xl font-bold mb-4 text-blue-400">Ways to Get Involved</h2>
                <ul className="space-y-4 text-zinc-300">
                  <li>
                    <strong className="text-white">Join Our Community:</strong> Engage in discussions, share ideas, and
                    connect with like-minded individuals passionate about decentralized strategy.
                  </li>
                  <li>
                    <strong className="text-white">Contribute to Development:</strong> If you're a developer, consider
                    contributing to our open-source projects or suggesting improvements to our agents.
                  </li>
                  <li>
                    <strong className="text-white">Spread the Word:</strong> Help us grow by sharing Dicerix with your
                    network and on social media platforms.
                  </li>
                  <li>
                    <strong className="text-white">Provide Feedback:</strong> Your insights are valuable. Share your
                    thoughts on our agents, simulations, and overall platform to help us improve.
                  </li>
                </ul>
              </div>
              <div>
                <h2 className="text-2xl font-bold mb-4 text-blue-400">Stay Connected</h2>
                <p className="text-zinc-300 mb-4">
                  Follow us on our social media channels to stay updated on the latest developments:
                </p>
                <div className="flex space-x-4 mb-6">
                  <Button variant="outline" size="icon">
                    <Twitter className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon">
                    <MessageCircle className="h-4 w-4" />
                  </Button>
                  <Button variant="outline" size="icon">
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
                <p className="text-zinc-300">Or subscribe to our newsletter for exclusive updates and insights:</p>
                <form className="mt-4 space-y-4">
                  <Input type="email" placeholder="Enter your email" />
                  <Button type="submit" className="w-full">
                    Subscribe
                  </Button>
                </form>
              </div>
            </div>

            <div className="bg-zinc-800/50 rounded-lg p-8 mb-16">
              <h2 className="text-2xl font-bold mb-4 text-blue-400">Share Your Ideas</h2>
              <p className="text-zinc-300 mb-6">
                Have a brilliant idea for Dicerix? We'd love to hear it! Submit your thoughts below:
              </p>
              <form className="space-y-4">
                <Input placeholder="Your Name" />
                <Input type="email" placeholder="Your Email" />
                <Textarea placeholder="Your Idea" className="h-32" />
                <Button type="submit">Submit Idea</Button>
              </form>
            </div>

            <div className="text-center">
              <h2 className="text-2xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
                Ready to Make a Difference?
              </h2>
              <p className="text-zinc-300 mb-6">
                Your participation can help shape the future of decentralized decision-making. Join us in this exciting
                journey!
              </p>
              <Button asChild>
                <Link href="/about">Learn More About Our Mission</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

