import { ImageResponse } from "next/server"

export const runtime = "edge"

export const size = {
  width: 32,
  height: 32,
}
export const contentType = "image/png"

export default function Icon() {
  return new ImageResponse(
    <div
      style={{
        width: "100%",
        height: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "transparent",
      }}
    >
      {/* Simple square with the dice logo */}
      <img
        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/3c75c929-ca9f-4cb5-b930-6097f2470b0a-eSvOHE2Vpg09KjGe5xFzp2ZICB7h3Y.webp"
        alt="DeFiDice Icon"
        style={{
          width: "100%",
          height: "100%",
          objectFit: "contain",
        }}
      />
    </div>,
    {
      ...size,
    },
  )
}

