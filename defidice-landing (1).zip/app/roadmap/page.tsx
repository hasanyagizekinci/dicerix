import type { Metadata } from "next"
import Header from "@/components/header"
import Footer from "@/components/footer"

export const metadata: Metadata = {
  title: "Dicerix Roadmap",
  description:
    "Explore the exciting journey ahead for Dicerix as we reshape digital strategy and decentralized decision-making.",
}

export default function RoadmapPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-900 to-black text-white">
      <Header />
      <main className="pt-20">
        <div className="py-20">
          <div className="container mx-auto px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
              Our Roadmap
            </h1>
            <p className="text-lg text-zinc-300 mb-12">
              At Dicerix, every milestone brings us closer to reshaping digital strategy. Here's our exciting journey
              ahead:
            </p>

            <div className="space-y-12">
              <div className="border-l-4 border-blue-500 pl-6">
                <h2 className="text-2xl font-bold text-blue-400 mb-4">Phase 1: The Genesis (Now – Next 45 Days)</h2>
                <h3 className="text-xl font-semibold text-purple-400 mb-2">Launch of ByteJack:</h3>
                <p className="text-zinc-300">
                  Our debut agent is now undergoing a 45-day strategic challenge, with every move recorded on-chain to
                  establish a transparent legacy.
                </p>
              </div>

              <div className="border-l-4 border-blue-500 pl-6">
                <h2 className="text-2xl font-bold text-blue-400 mb-4">Phase 2: Expanding Our Lineup (Post-45 Days)</h2>
                <h3 className="text-xl font-semibold text-purple-400 mb-2">Introducing Quantum Bluff:</h3>
                <p className="text-zinc-300 mb-4">
                  Following ByteJack's challenge, we'll unveil Quantum Bluff—designed to redefine tactical
                  decision-making.
                </p>
                <h3 className="text-xl font-semibold text-purple-400 mb-2">Launching CyberStriker:</h3>
                <p className="text-zinc-300">
                  Alongside, CyberStriker will enter the arena, bringing dynamic, real-time strategy to the forefront.
                </p>
              </div>

              <div className="border-l-4 border-blue-500 pl-6">
                <h2 className="text-2xl font-bold text-blue-400 mb-4">
                  Phase 3: On-Chain Integration & Community Empowerment
                </h2>
                <h3 className="text-xl font-semibold text-purple-400 mb-2">On-Chain Collection:</h3>
                <p className="text-zinc-300 mb-4">
                  Proven agents will be immortalized in our exclusive on-chain collection, creating a verifiable archive
                  of digital strategy.
                </p>
                <h3 className="text-xl font-semibold text-purple-400 mb-2">Community Contributions:</h3>
                <p className="text-zinc-300">
                  We invite our community to support and drive our agents' evolution through direct contributions.
                </p>
              </div>

              <div className="border-l-4 border-blue-500 pl-6">
                <h2 className="text-2xl font-bold text-blue-400 mb-4">Phase 4: Ecosystem Expansion</h2>
                <h3 className="text-xl font-semibold text-purple-400 mb-2">Agent Rental & Customization:</h3>
                <p className="text-zinc-300 mb-4">
                  Soon, you'll be able to harness our agents' expertise by renting and customizing them for your unique
                  projects.
                </p>
                <h3 className="text-xl font-semibold text-purple-400 mb-2">Broadening the Vision:</h3>
                <p className="text-zinc-300">
                  We'll continue to innovate with new simulation challenges and expand our roster to push the boundaries
                  of decentralized strategy.
                </p>
              </div>
            </div>

            <p className="text-lg font-semibold text-blue-400 mt-12">
              Join us as we embark on this revolutionary journey—each step is a leap toward a bold new future in digital
              strategy.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}

