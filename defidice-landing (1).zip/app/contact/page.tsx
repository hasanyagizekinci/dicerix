import type { Metadata } from "next"
import Header from "@/components/header"
import Footer from "@/components/footer"
import ContactForm from "@/components/contact-form"
import { Button } from "@/components/ui/button"
import { Mail, MessageCircle, Phone } from "lucide-react"

export const metadata: Metadata = {
  title: "Contact Us | Dicerix",
  description: "Get in touch with the Dicerix team for inquiries, support, or collaboration opportunities.",
}

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-900 to-black text-white">
      <Header />
      <main className="pt-20">
        <section className="py-20">
          <div className="container mx-auto px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
              Contact Us
            </h1>
            <p className="text-xl text-zinc-300 mb-12">
              Have questions, feedback, or want to collaborate? We'd love to hear from you. Reach out to the Dicerix
              team using any of the methods below.
            </p>

            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <h2 className="text-2xl font-bold mb-6 text-blue-400">Send Us a Message</h2>
                <ContactForm />
              </div>
              <div>
                <h2 className="text-2xl font-bold mb-6 text-blue-400">Other Ways to Connect</h2>
                <div className="space-y-6">
                  <div className="flex items-center space-x-4">
                    <Button variant="outline" size="icon">
                      <Mail className="h-4 w-4" />
                    </Button>
                    <div>
                      <h3 className="font-semibold">Email</h3>
                      <p className="text-zinc-300">support@dicerix.com</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <Button variant="outline" size="icon">
                      <Phone className="h-4 w-4" />
                    </Button>
                    <div>
                      <h3 className="font-semibold">Phone</h3>
                      <p className="text-zinc-300">+1 (555) 123-4567</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <Button variant="outline" size="icon">
                      <MessageCircle className="h-4 w-4" />
                    </Button>
                    <div>
                      <h3 className="font-semibold">Live Chat</h3>
                      <p className="text-zinc-300">Available 24/7 on our website</p>
                    </div>
                  </div>
                </div>

                <div className="mt-12">
                  <h2 className="text-2xl font-bold mb-6 text-blue-400">Visit Us</h2>
                  <p className="text-zinc-300">
                    Dicerix Headquarters
                    <br />
                    123 Blockchain Boulevard
                    <br />
                    Crypto City, CC 12345
                    <br />
                    Decentraland
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

