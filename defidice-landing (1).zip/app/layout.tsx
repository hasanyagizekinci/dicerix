import type React from "react"
import type { Metadata } from "next"
import { Inter, Space_Grotesk } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" })
const spaceGrotesk = Space_Grotesk({ subsets: ["latin"], variable: "--font-space-grotesk" })

export const metadata: Metadata = {
  title: "Dicerix: Revolutionizing Decision Making",
  description:
    "Step into the future of digital strategy and decentralized innovation with Dicerix. Experience high-stakes simulations and evolving AI agents.",
  icons: {
    icon: [
      { url: "/icon.png", sizes: "32x32", type: "image/png" },
      { url: "/icon.png", sizes: "16x16", type: "image/png" },
    ],
    apple: [{ url: "/icon.png" }],
  },
  openGraph: {
    title: "Dicerix: Revolutionizing Decision Making",
    description:
      "Step into the future of digital strategy and decentralized innovation with Dicerix. Experience high-stakes simulations and evolving AI agents.",
    images: [
      {
        url: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/wideangle_shot_of_a_dynamic_landing_page_background_seamlessly-2025-02-15-131301%20(1).png-eICbn8ZYFhyvDqMoYGG5VqSNihAYCj.jpeg",
      },
    ],
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en" className={`${inter.variable} ${spaceGrotesk.variable}`}>
      <body className="font-sans">
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:top-0 focus:left-0 bg-blue-500 text-white p-2"
        >
          Skip to main content
        </a>
        {children}
      </body>
    </html>
  )
}



import './globals.css'