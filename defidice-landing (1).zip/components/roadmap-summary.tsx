"use client"

import { motion } from "framer-motion"
import { ArrowRight } from "lucide-react"
import Link from "next/link"

const roadmapItems = [
  {
    phase: "Phase 1",
    title: "The Genesis",
    description: "Launch of ByteJack: 45-day strategic challenge",
  },
  {
    phase: "Phase 2",
    title: "Expanding Our Lineup",
    description: "Introducing Quantum Bluff and CyberStriker",
  },
  {
    phase: "Phase 3",
    title: "On-Chain Integration",
    description: "On-Chain Collection and Community Contributions",
  },
  {
    phase: "Phase 4",
    title: "Ecosystem Expansion",
    description: "Agent Rental & Customization, Broadening the Vision",
  },
]

export default function RoadmapSummary() {
  return (
    <section className="py-20 bg-gradient-to-b from-black to-zinc-900">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
            Our Roadmap
          </h2>
          <p className="text-lg text-zinc-400 max-w-2xl mx-auto">
            Explore the exciting journey ahead as we reshape digital strategy and decentralized decision-making.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {roadmapItems.map((item, index) => (
            <motion.div
              key={item.phase}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="bg-zinc-800/50 backdrop-blur-sm border border-zinc-700 rounded-lg p-6 hover:border-blue-500/50 transition-colors"
            >
              <div className="text-blue-400 font-semibold mb-2">{item.phase}</div>
              <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
              <p className="text-zinc-400">{item.description}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <Link
            href="/roadmap"
            className="inline-flex items-center text-blue-400 hover:text-blue-300 transition-colors"
          >
            View Full Roadmap
            <ArrowRight className="ml-2 h-4 w-4" />
          </Link>
        </motion.div>
      </div>
    </section>
  )
}

