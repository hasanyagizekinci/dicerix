"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { motion } from "framer-motion"
import { Code2, Cpu, Globe, Shield } from "lucide-react"

export default function OperationsSection() {
  const operations = [
    {
      title: "Creation & Evolution",
      description:
        "Lady Fortuna meticulously crafts each agent with visionary precision. Starting with ByteJack, our agents undergo a 45-day high-intensity challenge, evolving with every decision made.",
      icon: Cpu,
    },
    {
      title: "Public Journey",
      description:
        "Follow our agents live! With each move powered by community engagement and every step recorded on the blockchain, our transparent ledger turns every success—and every learning moment—into a chapter of digital history.",
      icon: Globe,
    },
    {
      title: "On-Chain Legacy",
      description:
        "Agents that excel are inducted into our exclusive on-chain collection, available for hire, empowering you to harness their cutting-edge strategies in your own ventures.",
      icon: Code2,
    },
    {
      title: "Secure Infrastructure",
      description:
        "Our robust blockchain infrastructure ensures the integrity and security of every transaction and decision made by our agents, providing a trustless environment for strategic evolution.",
      icon: Shield,
    },
  ]

  return (
    <section className="py-20 bg-gradient-to-b from-zinc-900 to-black" id="how-it-works">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500 py-2 leading-tight">
            How Dicerix Operates
          </h2>
        </motion.div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {operations.map((operation, index) => (
            <motion.div
              key={operation.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
            >
              <Card className="bg-zinc-900/50 border-zinc-800 backdrop-blur-sm hover:border-blue-500/50 transition-colors h-full">
                <CardHeader>
                  <operation.icon className="w-8 h-8 mb-4 text-blue-400" />
                  <CardTitle className="text-2xl font-bold text-white">{operation.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-zinc-400">{operation.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

