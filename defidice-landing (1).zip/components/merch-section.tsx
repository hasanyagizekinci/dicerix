"use client"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Copy, ShoppingCart } from "lucide-react"
import { motion } from "framer-motion"
import Image from "next/image"
import { useState } from "react"
import { XLogo, DiscordLogo, TelegramLogo, InstagramLogo, TikTokLogo } from "./social-icons"
const Discord = DiscordLogo
const Telegram = TelegramLogo

interface Product {
  id: string
  name: string
  description: string
  price: string
  image: string
}

export default function MerchSection() {
  const walletAddress = "0xYourWalletAddressHere"
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)

  const handleCopyAddress = () => {
    navigator.clipboard.writeText(walletAddress)
  }

  const products: Product[] = [
    {
      id: "1",
      name: "Lady Fortuna Premium Tee",
      description: "Featuring our iconic digital matriarch in stunning neon print",
      price: "45 USDC",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/lady%20matriarch.png-zZXjKBlWo7NFUvNppC1onxGDdmxQdi.jpeg",
    },
    {
      id: "2",
      name: "ByteJack Cyber Hoodie",
      description: "Limited edition hoodie with glowing accent details",
      price: "85 USDC",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/bytejac.png-OD7QJMV6D6WpaoTF6pVwHtMGYAdCZP.jpeg",
    },
    {
      id: "3",
      name: "Digital Realm Mouse Pad",
      description: "Extra-large gaming surface with reactive LED edges",
      price: "35 USDC",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/wideangle_shot_of_a_dynamic_landing_page_background_seamlessly-2025-02-15-131301%20(1).png-eICbn8ZYFhyvDqMoYGG5VqSNihAYCj.jpeg",
    },
  ]

  return (
    <section className="py-20 bg-gradient-to-b from-black to-zinc-900" id="merch">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
            Gear Up, Power Up, and Join the Revolution!
          </h2>
          <p className="text-lg text-zinc-400 max-w-3xl mx-auto mb-12">
            Show your allegiance to the digital strategy revolution with exclusive Dicerix merchandise! From futuristic
            tees to limited-edition accessories, our collection captures the spirit of Lady Fortuna and her dynamic
            agents.
          </p>

          {/* Product Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {products.map((product) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
                viewport={{ once: true }}
                className="group relative"
              >
                <div className="relative aspect-square overflow-hidden rounded-xl bg-zinc-900/50 border border-zinc-800 backdrop-blur-sm">
                  <Image
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    fill
                    className="object-cover transition-transform group-hover:scale-105"
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/50 to-transparent">
                    <div className="absolute bottom-0 left-0 right-0 p-4">
                      <h3 className="text-xl font-bold text-white mb-2">{product.name}</h3>
                      <p className="text-sm text-zinc-400 mb-4">{product.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-blue-400 font-bold">{product.price}</span>
                        <Button
                          size="sm"
                          className="bg-blue-500/20 text-blue-400 border border-blue-500/50 hover:bg-blue-500/30"
                        >
                          <ShoppingCart className="w-4 h-4 mr-2" />
                          Add to Cart
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Contribution Section */}
          <div className="max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
              Support the Future
            </h3>
            <p className="text-zinc-400 mb-6">
              Power up the action by sending a crypto contribution directly to Dicerix's wallet. Every token helps forge
              our on-chain legacy.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <div className="flex gap-2 flex-1">
                <Input value={walletAddress} readOnly className="bg-zinc-900/50 border-zinc-800 text-zinc-400" />
                <Button variant="outline" className="border-blue-500 text-blue-400" onClick={handleCopyAddress}>
                  <Copy className="w-4 h-4" />
                </Button>
              </div>
              <Button className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white">
                Contribute Now
              </Button>
            </div>
          </div>

          {/* Social Links */}
          <div className="flex justify-center gap-6">
            <Button variant="ghost" className="text-zinc-400 hover:text-blue-400">
              <XLogo className="w-6 h-6" />
            </Button>
            <Button variant="ghost" className="text-zinc-400 hover:text-blue-400">
              <DiscordLogo className="w-6 h-6" />
            </Button>
            <Button variant="ghost" className="text-zinc-400 hover:text-blue-400">
              <TelegramLogo className="w-6 h-6" />
            </Button>
            <Button variant="ghost" className="text-zinc-400 hover:text-blue-400">
              <TikTokLogo className="w-6 h-6" />
            </Button>
            <Button variant="ghost" className="text-zinc-400 hover:text-blue-400">
              <InstagramLogo className="w-6 h-6" />
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

