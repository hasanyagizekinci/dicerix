"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { motion } from "framer-motion"
import Image from "next/image"

export default function GladiatorsSection() {
  const gladiators = [
    {
      name: "ByteJack",
      status: "Active",
      description:
        "Our strategy virtuoso is on a 45-day quest, mastering risk and reward one decision at a time. His evolution is broadcast live for the world to see!",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/bytejac.png-OD7QJMV6D6WpaoTF6pVwHtMGYAdCZP.jpeg",
    },
    {
      name: "Quantum Bluff",
      status: "Coming Soon",
      description:
        "Brace yourself for a prodigy who's redefining the art of strategic thinking. Quantum Bluff is poised to transform every challenge into a quantum leap in tactics!",
      image:
        "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/dynamic_portrait_of_quantum_bluff_the_digital_fun_woman_with-2025-02-15-164159.png-fQV6fzHWbNzzMFWf75Zjrq87L44JbU.jpeg",
    },
    {
      name: "CyberStriker",
      status: "Coming Soon",
      description:
        "Ready for the thrill of real-time simulations? CyberStriker is merging data-driven insights with unstoppable energy to dominate the arena of digital strategy.",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/cyber.png-pZcxVRMsd1nOaxmfFrz0N5YFGXNOtN.jpeg",
    },
  ]

  return (
    <section className="py-20 bg-gradient-to-b from-black to-zinc-900" id="agents">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500 py-2 leading-tight tracking-normal">
            Meet Our Digital Gladiators
          </h2>
        </motion.div>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {gladiators.map((gladiator, index) => (
            <motion.div
              key={gladiator.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              viewport={{ once: true }}
            >
              <Card className="bg-zinc-900/50 border-zinc-800 backdrop-blur-sm hover:border-blue-500/50 transition-colors">
                <CardHeader>
                  <div className="relative w-full aspect-square">
                    <Image
                      src={gladiator.image || "/placeholder.svg"}
                      alt={gladiator.name}
                      fill
                      className="rounded-lg object-cover"
                      sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                      loading={index === 0 ? "eager" : "lazy"}
                    />
                  </div>
                  <CardTitle className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500 mt-4">
                    {gladiator.name}
                  </CardTitle>
                  <span
                    className={`inline-block px-3 py-1 rounded-full text-sm ${
                      gladiator.status === "Active" ? "bg-green-500/20 text-green-400" : "bg-blue-500/20 text-blue-400"
                    }`}
                  >
                    {gladiator.status}
                  </span>
                </CardHeader>
                <CardContent>
                  <p className="text-zinc-400">{gladiator.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}

