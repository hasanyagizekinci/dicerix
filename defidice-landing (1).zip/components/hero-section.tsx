"use client"

import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import Image from "next/image"
import Link from "next/link"
import { useEffect, useState } from "react"

export default function HeroSection() {
  const [scrollY, setScrollY] = useState(0)

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY)
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden py-20">
      <Image
        src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/a_website_banner_that_is_about_futuristic_gambling-2025-02-15-165112.png-aYW03y3RlnUv6K0LkaCpdFYa6WTKiW.jpeg"
        alt="Digital Realm"
        fill
        className="object-cover object-center"
        priority
        sizes="100vw"
        style={{ transform: `translateY(${scrollY * 0.5}px)` }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-black/80 via-black/60 to-black/80 z-10" />
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center relative z-20">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-4xl md:text-6xl font-extrabold mb-6 py-2 bg-clip-text text-transparent bg-gradient-to-r from-cyan-300 via-purple-300 to-amber-300 drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]"
          >
            Welcome to Dicerix – Ignite Your Digital Challenge!
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl md:text-2xl text-zinc-200 mb-8 drop-shadow-[0_1px_1px_rgba(0,0,0,0.8)]"
          >
            Watch as Lady Fortuna launches ByteJack into the strategic arena while her next-gen agents—Quantum Bluff and
            CyberStriker—prepare to redefine digital decision-making!
          </motion.p>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex justify-center"
          >
            <Button
              size="lg"
              className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white"
              asChild
            >
              <Link href="/legacy">Explore the Legacy</Link>
            </Button>
          </motion.div>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent" />
    </section>
  )
}

