"use client"

import { motion, useScroll, useTransform } from "framer-motion"
import Image from "next/image"
import { useRef } from "react"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function LadyFortunaSection() {
  const ref = useRef(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  })

  const y = useTransform(scrollYProgress, [0, 1], [100, -100])
  const opacity = useTransform(scrollYProgress, [0, 0.5, 1], [0, 1, 0])

  return (
    <section ref={ref} className="py-20 bg-gradient-to-b from-black to-zinc-900" id="about">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative aspect-square lg:aspect-auto lg:h-[600px] rounded-2xl overflow-hidden"
          >
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/lady%20matriarch.png-zZXjKBlWo7NFUvNppC1onxGDdmxQdi.jpeg"
              alt="Lady Fortuna"
              fill
              className="object-cover object-center"
              sizes="(max-width: 768px) 100vw, 50vw"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <div className="inline-block px-4 py-2 bg-blue-500/20 backdrop-blur-sm rounded-full text-blue-400 text-sm mb-4">
                Digital Matriarch
              </div>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <motion.h2
              style={{ y, opacity }}
              className="text-4xl md:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500"
            >
              Meet Lady Fortuna
            </motion.h2>
            <motion.p style={{ y, opacity }} className="text-lg text-zinc-400">
              Deep within the cryptoverse, where destiny meets code, stands Lady Fortuna—a digital matriarch with one
              audacious mission: to reinvent the art of strategic challenge by birthing an elite legion of self-evolving
              agents.
            </motion.p>
            <motion.p style={{ y, opacity }} className="text-lg text-zinc-400">
              With her state-of-the-art neural interface and unparalleled strategic insight, Lady Fortuna oversees the
              evolution of each agent, ensuring they push the boundaries of what's possible in the digital realm.
            </motion.p>
            <motion.div style={{ y, opacity }} className="grid grid-cols-2 gap-6 pt-6">
              <div className="space-y-2">
                <div className="text-3xl font-bold text-blue-400">45+</div>
                <div className="text-sm text-zinc-500">Days of Training</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold text-purple-400">100%</div>
                <div className="text-sm text-zinc-500">On-Chain Transparency</div>
              </div>
            </motion.div>
          </motion.div>
        </div>
        <div className="mt-8 text-center">
          <Button asChild className="bg-blue-500 hover:bg-blue-600 text-white">
            <Link href="/lady-fortuna">Learn More About Lady Fortuna</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}

