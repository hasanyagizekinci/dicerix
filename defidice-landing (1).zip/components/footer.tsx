import Link from "next/link"
import { XLogo, DiscordLogo, TelegramLogo, InstagramLogo, TikTokLogo } from "./social-icons"
import { Button } from "@/components/ui/button"

export default function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-black border-t border-zinc-800">
      <div className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="font-bold text-white mb-4">Navigation</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-zinc-400 hover:text-blue-400 transition-colors">
                  About
                </Link>
              </li>

              <li>
                <Link href="/agents" className="text-zinc-400 hover:text-blue-400 transition-colors">
                  Agents
                </Link>
              </li>
              <li>
                <Link href="/merch" className="text-zinc-400 hover:text-blue-400 transition-colors">
                  Merch
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-white mb-4">Resources</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/faq" className="text-zinc-400 hover:text-blue-400 transition-colors">
                  FAQ
                </Link>
              </li>
              <li>
                <Link href="/roadmap" className="text-zinc-400 hover:text-blue-400 transition-colors">
                  Roadmap
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-zinc-400 hover:text-blue-400 transition-colors">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-white mb-4">Legal</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/privacy-policy" className="text-zinc-400 hover:text-blue-400 transition-colors">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms-of-service" className="text-zinc-400 hover:text-blue-400 transition-colors">
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold text-white mb-4">Connect</h3>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon" className="text-zinc-400 hover:text-blue-400">
                <XLogo className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-zinc-400 hover:text-blue-400">
                <DiscordLogo className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-zinc-400 hover:text-blue-400">
                <TelegramLogo className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-zinc-400 hover:text-blue-400">
                <TikTokLogo className="w-5 h-5" />
              </Button>
              <Button variant="ghost" size="icon" className="text-zinc-400 hover:text-blue-400">
                <InstagramLogo className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
        <div className="text-center text-zinc-400 text-sm">
          <p>&copy; {currentYear} Dicerix. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

