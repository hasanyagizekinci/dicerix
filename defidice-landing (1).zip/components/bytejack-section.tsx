"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ArrowRight, Award, Brain, Target } from "lucide-react"
import Link from "next/link"

export default function ByteJackSection() {
  return (
    <section className="py-20 bg-gradient-to-b from-zinc-900 to-black">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="order-2 lg:order-1 space-y-6"
          >
            <h2 className="text-4xl md:text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
              ByteJack: The Strategic Virtuoso
            </h2>
            <p className="text-lg text-zinc-400">
              Our debut agent is already making waves in the simulation arena. Every decision he makes is a lesson in
              strategy and audacity, every move a building block of an on-chain legacy.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-start space-x-4">
                <div className="bg-blue-500/20 p-3 rounded-lg">
                  <Brain className="w-6 h-6 text-blue-400" />
                </div>
                <div>
                  <h3 className="font-bold text-white mb-1">Strategic Mastery</h3>
                  <p className="text-sm text-zinc-400">Advanced decision-making algorithms</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="bg-purple-500/20 p-3 rounded-lg">
                  <Target className="w-6 h-6 text-purple-400" />
                </div>
                <div>
                  <h3 className="font-bold text-white mb-1">Precision Execution</h3>
                  <p className="text-sm text-zinc-400">99.9% accuracy in simulations</p>
                </div>
              </div>
            </div>
            <div className="pt-6">
              <Button
                size="lg"
                className="group bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white"
                asChild
              >
                <Link href="/bytejack-progress">
                  Track ByteJack's Progress
                  <ArrowRight className="w-4 h-4 ml-2 transition-transform group-hover:translate-x-1" />
                </Link>
              </Button>
            </div>
          </motion.div>
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="order-1 lg:order-2 relative aspect-square lg:aspect-auto lg:h-[600px] rounded-2xl overflow-hidden"
          >
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/bytejac.png-OD7QJMV6D6WpaoTF6pVwHtMGYAdCZP.jpeg"
              alt="ByteJack"
              fill
              className="object-cover object-center"
              sizes="(max-width: 768px) 100vw, 50vw"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <div className="flex items-center space-x-4">
                <div className="inline-block px-4 py-2 bg-blue-500/20 backdrop-blur-sm rounded-full text-blue-400 text-sm">
                  Active Agent
                </div>
                <Award className="w-6 h-6 text-gold-400" />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  )
}

