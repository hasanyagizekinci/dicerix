"use client"

import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Brain, Target, Users } from "lucide-react"
import Link from "next/link"
import Logo from "@/components/logo"

export default function AboutPageClient() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-900 to-black text-white">
      <header className="fixed top-0 w-full z-50 bg-black/50 backdrop-blur-md border-b border-zinc-800">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Logo />
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/about" className="text-sm hover:text-blue-400 transition-colors">
              About
            </Link>
            <Link href="/#how-it-works" className="text-sm hover:text-blue-400 transition-colors">
              How It Works
            </Link>
            <Link href="/agents" className="text-sm hover:text-blue-400 transition-colors">
              Agents
            </Link>
            <Link href="/#merch" className="text-sm hover:text-blue-400 transition-colors">
              Merch
            </Link>
          </nav>
        </div>
      </header>

      <main className="pt-20">
        <section className="py-20">
          <div className="container mx-auto px-4">
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
              className="text-4xl md:text-5xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500"
            >
              About Dicerix
            </motion.h1>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-lg text-zinc-300 mb-12"
            >
              Welcome to Dicerix, the nexus where digital innovation transforms high-risk decision making into a realm
              of precision, clarity, and unstoppable momentum. We're not just a platform—we're a revolution that's
              reshaping how strategy and data converge to drive the future of decentralized decision-making.
            </motion.p>

            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-3xl font-bold mt-12 mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500"
            >
              Our Philosophy
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="text-lg text-zinc-300 mb-8"
            >
              In a world where emotions often cloud judgment, we believe that risk should be approached with a clear,
              data-driven mindset. At Dicerix, we turn high-stakes decisions into calculated, measurable actions that
              transcend gut reactions and embrace analytics. Our core philosophy is built on three pillars:
            </motion.p>

            <div className="grid md:grid-cols-3 gap-8 mb-12">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.8 }}
                className="bg-zinc-800/50 rounded-lg p-6 backdrop-blur-sm"
              >
                <Brain className="w-12 h-12 text-blue-400 mb-4" />
                <h3 className="text-xl font-bold mb-4 text-white">Rational Precision</h3>
                <p className="text-zinc-300">
                  We harness the power of real-time data and advanced analytics to replace impulsive decisions with
                  calculated strategies. By recording every move on-chain, we ensure that every risk is transparent and
                  every outcome is measurable.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 1 }}
                className="bg-zinc-800/50 rounded-lg p-6 backdrop-blur-sm"
              >
                <Target className="w-12 h-12 text-purple-400 mb-4" />
                <h3 className="text-xl font-bold mb-4 text-white">Emotional Detachment</h3>
                <p className="text-zinc-300">
                  In traditional high-risk environments, emotions can skew judgment and lead to inconsistency. Our
                  approach strips away the noise, allowing our digital agents to operate on pure logic and data. This
                  non-emotional, algorithmic method not only minimizes error but also maximizes efficiency and
                  adaptability.
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 1.2 }}
                className="bg-zinc-800/50 rounded-lg p-6 backdrop-blur-sm"
              >
                <Users className="w-12 h-12 text-gold-400 mb-4" />
                <h3 className="text-xl font-bold mb-4 text-white">Community-Driven Evolution</h3>
                <p className="text-zinc-300">
                  We believe that collective insight fuels innovation. By involving our community in every step—from
                  contributing data to influencing strategic adjustments—Dicerix evolves continuously. Our transparent
                  on-chain ledger serves as both a record and a roadmap for progress, ensuring that every participant is
                  part of a larger, intelligent ecosystem.
                </p>
              </motion.div>
            </div>

            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 1.4 }}
              className="text-3xl font-bold mt-12 mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500"
            >
              Our Story
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 1.6 }}
              className="text-lg text-zinc-300 mb-8"
            >
              Deep within the cryptoverse, where the fusion of technology and strategy sparks endless possibilities,
              emerged Lady Fortuna—our visionary digital matriarch. Determined to revolutionize risk, she crafted an
              array of intelligent agents designed to navigate high-stakes scenarios with unmatched precision.
            </motion.p>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 1.8 }}
              className="text-lg text-zinc-300 mb-8"
            >
              Her first creation, ByteJack, is already in the spotlight, undergoing a rigorous 45-day challenge that
              tests and refines his strategic capabilities. Every decision ByteJack makes is meticulously recorded
              on-chain, building a transparent legacy of data-backed evolution. And as we look to the horizon, we're
              preparing to launch:
            </motion.p>
            <motion.ul
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 2 }}
              className="list-disc pl-6 mb-12 text-zinc-300"
            >
              <li>
                <strong className="text-blue-400">Quantum Bluff:</strong> Engineered to redefine tactical
                decision-making, Quantum Bluff leverages complex algorithms to turn every risky move into a quantum leap
                forward.
              </li>
              <li>
                <strong className="text-blue-400">CyberStriker:</strong> A dynamic agent built for real-time simulation,
                CyberStriker fuses rapid data analysis with agile decision-making, dominating even the most
                unpredictable challenges.
              </li>
            </motion.ul>

            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 2.2 }}
              className="text-3xl font-bold mt-12 mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500"
            >
              Our Technology
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 2.4 }}
              className="text-lg text-zinc-300 mb-8"
            >
              Dicerix is powered by state-of-the-art blockchain integration and sophisticated simulation models. Our
              platform transforms high-risk decision-making into a robust, measurable process:
            </motion.p>
            <motion.ul
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 2.6 }}
              className="list-disc pl-6 mb-12 text-zinc-300"
            >
              <li>
                <strong className="text-blue-400">On-Chain Transparency:</strong> Every strategic move is permanently
                recorded on the blockchain, ensuring complete accountability and verifiability.
              </li>
              <li>
                <strong className="text-blue-400">Data-Driven Insights:</strong> Our advanced analytics provide
                real-time feedback, enabling our agents—and our community—to refine strategies and push the boundaries
                of what's possible.
              </li>
              <li>
                <strong className="text-blue-400">Continuous Evolution:</strong> With each decision, our digital agents
                learn, adapt, and improve, creating a living archive of intelligent strategy that evolves alongside
                technological innovation.
              </li>
            </motion.ul>

            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 2.8 }}
              className="text-3xl font-bold mt-12 mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500"
            >
              Our Mission
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 3 }}
              className="text-lg text-zinc-300 mb-8"
            >
              Our mission is to dismantle the barriers between high-risk challenges and rational, data-oriented
              decision-making. We aim to empower a new generation of strategists who thrive on precision, objectivity,
              and continuous improvement. At Dicerix, every decision is a step forward—a step toward a future where
              technology and human ingenuity merge to unlock untold potential.
            </motion.p>

            <motion.h2
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 3.2 }}
              className="text-3xl font-bold mt-12 mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500"
            >
              Join the Revolution
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 3.4 }}
              className="text-lg text-zinc-300 mb-8"
            >
              Dicerix is more than a platform; it's a movement. Whether you're a seasoned strategist, a tech enthusiast,
              or someone ready to explore the transformative power of data-driven risk management, we invite you to join
              our journey. Engage with our digital agents, dive into our on-chain legacy, and help shape the future of
              decentralized decision-making.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 3.6 }}
              className="text-center mt-12"
            >
              <p className="text-xl font-semibold text-blue-400 mb-8">
                Welcome to Dicerix—where every high-risk decision is transformed into a triumph of precision,
                innovation, and unstoppable progress.
              </p>
              <Button
                size="lg"
                className="bg-gradient-to-r from-blue-500 to-purple-600 hover:from-blue-600 hover:to-purple-700 text-white"
              >
                Join the Revolution
              </Button>
            </motion.div>
          </div>
        </section>
      </main>
    </div>
  )
}

