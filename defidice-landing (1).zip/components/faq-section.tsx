"use client"

import { motion } from "framer-motion"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

export default function FAQSection() {
  const faqs = [
    {
      question: "What is Dicerix?",
      answer:
        "Dicerix is a digital strategy simulation platform where cutting-edge digital agents evolve by making strategic decisions. Our platform combines blockchain transparency, community engagement, and innovative simulations to create a verifiable on-chain legacy of digital decision-making.",
    },
    {
      question: "Who is behind Dicerix?",
      answer:
        "Dicerix is driven by a visionary concept led by our digital matriarch, Lady Fortuna. Her first creation, ByteJack, is currently undergoing a 45-day strategic challenge, with additional agents like Quantum Bluff and CyberStriker in development. Together, they represent our commitment to transforming decentralized strategy.",
    },
    {
      question: "How do the digital agents work?",
      answer:
        "Our agents simulate high-stakes strategic scenarios in a controlled environment. Every decision they make is recorded on-chain, allowing users to track their evolution, performance, and overall legacy. While the technology is still evolving, the simulations provide a real-time look at how these agents adapt and grow.",
    },
    {
      question: 'What does "on-chain legacy" mean?',
      answer:
        "An on-chain legacy means that every move, decision, and result of our agents is recorded on the blockchain. This ensures complete transparency, allowing anyone to verify and follow the progression of our agents over time.",
    },
    {
      question: "How can I support or get involved with Dicerix?",
      answer:
        "There are several ways to join the revolution: 1) Community Engagement: Follow us on social media to stay updated and join discussions. 2) Crypto Contributions: Support our agents by sending crypto contributions directly to ByteJack's wallet. 3) Merchandise: Show your support by exploring our exclusive Dicerix merchandise available on our site.",
    },
    {
      question: "Is Dicerix a gambling platform?",
      answer:
        "No, Dicerix is designed as a digital strategy simulation platform. Although it draws inspiration from gaming and high-stakes scenarios, our focus is on strategic decision-making, transparent evolution, and decentralized innovation—not traditional gambling.",
    },
    {
      question: "What stage is the project currently in?",
      answer:
        "We are in the early, concept-driven phase of Dicerix. Our initial agent, ByteJack, is actively undergoing a 45-day challenge, and we're building momentum with our upcoming agents. Our roadmap is transparent, and we invite community feedback as we evolve.",
    },
    {
      question: "How can I stay updated on new developments?",
      answer:
        "We encourage you to subscribe to our social media channels and check our website regularly. We publish updates, behind-the-scenes insights, and detailed progress reports as our agents evolve and our platform grows.",
    },
  ]

  return (
    <section className="py-20 bg-gradient-to-b from-zinc-900 to-black">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
            Frequently Asked Questions about Dicerix
          </h2>
          <p className="text-lg text-zinc-400 max-w-2xl mx-auto">
            Get quick answers to some of our most common questions. Dive deeper into the world of Dicerix and our
            digital agents.
          </p>
        </motion.div>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          viewport={{ once: true }}
        >
          <Accordion type="single" collapsible className="w-full max-w-4xl mx-auto">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left text-lg font-semibold text-blue-400">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-zinc-300">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </motion.div>
      </div>
    </section>
  )
}

