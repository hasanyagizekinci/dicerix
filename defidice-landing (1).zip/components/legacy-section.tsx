import { motion } from "framer-motion"

export default function LegacySection() {
  return (
    <section className="py-20 bg-gradient-to-b from-zinc-900 to-black" id="about">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto text-center"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-8 bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
            The Legacy of Dicerix
          </h2>
          <div className="space-y-6 text-lg text-zinc-400">
            <p>
              Deep within the cryptoverse, where destiny meets code, stands Lady Fortuna—a digital matriarch with one
              audacious mission: to reinvent the art of strategic challenge by birthing an elite legion of self-evolving
              agents.
            </p>
            <p>
              Her debut creation, ByteJack, is already making waves in our simulation arena. Every decision he makes is
              a lesson in strategy and audacity, every move a building block of an on-chain legacy. And the excitement
              doesn't stop there! Soon, prepare to welcome Quantum Bluff, our master of high-stakes decision-making, and
              CyberStriker, our fearless competitor set to dominate in real-time simulations.
            </p>
            <p>
              At Dicerix, every move is recorded transparently on-chain, and every agent's journey is an open invitation
              to join the revolution of digital strategy and innovation.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  )
}

