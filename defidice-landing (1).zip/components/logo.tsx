import Link from "next/link"

export default function Logo() {
  return (
    <Link href="/" className="flex items-center">
      <span className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-blue-400 to-purple-500">
        Dicerix
      </span>
    </Link>
  )
}

